import os
import uuid
from fastapi import APIRouter, UploadFile, File, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select, and_, func

from services import doc_processor, db_service, process_document
from models import Document, DepartmentContent, ExtractedText

router = APIRouter()


# ------------------ Upload Document ------------------ #
@router.post("/api/v1/upload")
async def upload_document(file: UploadFile = File(...), background_tasks: BackgroundTasks = None):
    os.makedirs("uploads", exist_ok=True)
    file_path = os.path.join("uploads", file.filename)
    with open(file_path, "wb") as f:
        f.write(await file.read())

    new_doc = Document(filename=file.filename, file_path=file_path, status="uploaded")
    async with db_service.SessionLocal() as session:
        session.add(new_doc)
        await session.commit()

    if background_tasks:
        background_tasks.add_task(process_document, file_path, new_doc.id)

    return {"doc_id": str(new_doc.id), "filename": new_doc.filename, "status": "processing"}


# ------------------ Get Document Metadata ------------------ #
@router.get("/api/v1/documents/{doc_id}")
async def get_document(doc_id: str):
    try:
        doc_uuid = uuid.UUID(doc_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid document_id format")

    async with db_service.SessionLocal() as session:
        result = await session.execute(select(Document).where(Document.id == doc_uuid))
        doc = result.scalar_one_or_none()
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")

        return {
            "id": str(doc.id),
            "filename": doc.filename,
            "status": doc.status,
            "pages_count": doc.pages,
            "created_at": doc.created_at,
            "updated_at": doc.updated_at,
        }


# ------------------ Get Department Paragraphs ------------------ #
@router.get("/api/v1/departments/{doc_id}/{department}")
async def get_department_paragraphs(doc_id: str, department: str):
    try:
        doc_uuid = uuid.UUID(doc_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid document_id format")

    department = department.strip()

    async with db_service.SessionLocal() as session:
        result = await session.execute(
            select(DepartmentContent).where(
                and_(
                    DepartmentContent.document_id == doc_uuid,
                    func.lower(DepartmentContent.department) == department.lower()
                )
            ).order_by(DepartmentContent.page_start)
        )
        dept_entries = result.scalars().all()

        if not dept_entries:
            raise HTTPException(status_code=404, detail="Department content not found")

        # Return paragraph-level data
        paragraphs = []
        for entry in dept_entries:
            paragraphs.append({
                "content": entry.content,
                "page_start": entry.page_start,
                "page_end": entry.page_end,
                "confidence": entry.confidence,
                "keywords_matched": entry.keywords_matched,
                "pdf_path": entry.pdf_path
            })

        return {
            "document_id": doc_id,
            "department": department,
            "paragraphs": paragraphs
        }


# ------------------ Download Department PDF ------------------ #
@router.get("/api/v1/departments/{doc_id}/{department}/download")
async def download_department_pdf(doc_id: str, department: str):
    try:
        doc_uuid = uuid.UUID(doc_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid document_id format")

    async with db_service.SessionLocal() as session:
        result = await session.execute(
            select(DepartmentContent).where(
                and_(
                    DepartmentContent.document_id == doc_uuid,
                    func.lower(DepartmentContent.department) == department.lower()
                )
            )
        )
        dept = result.scalar_one_or_none()
        if not dept or not dept.pdf_path or not os.path.exists(dept.pdf_path):
            raise HTTPException(status_code=404, detail="PDF not found")

        return FileResponse(
            dept.pdf_path,
            media_type="application/pdf",
            filename=os.path.basename(dept.pdf_path)
        )


# ------------------ List All Departments ------------------ #
@router.get("/api/v1/departments/{doc_id}")
async def list_departments(doc_id: str):
    try:
        doc_uuid = uuid.UUID(doc_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid document_id format")

    async with db_service.SessionLocal() as session:
        result = await session.execute(
            select(DepartmentContent.department).where(DepartmentContent.document_id == doc_uuid)
        )
        departments = [row[0] for row in result.all()]
        return {"doc_id": doc_id, "departments": departments}


# ------------------ Get Full OCR Text (Page-wise) ------------------ #
@router.get("/api/v1/documents/{doc_id}/pages")
async def get_document_pages(doc_id: str):
    try:
        doc_uuid = uuid.UUID(doc_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid document_id format")

    async with db_service.SessionLocal() as session:
        result = await session.execute(select(ExtractedText).where(ExtractedText.document_id == doc_uuid).order_by(ExtractedText.page_number))
        pages = result.scalars().all()

        if not pages:
            raise HTTPException(status_code=404, detail="No extracted text found for this document")

        return [
            {
                "page_number": page.page_number,
                "text_content": page.text_content,
                "confidence": page.confidence
            }
            for page in pages
        ]

# In routes.py or your API router

@router.get("/api/v1/documents-list")
async def list_all_documents():
    """
    Returns all uploaded documents with their ID, filename, and status.
    """
    async with db_service.SessionLocal() as session:
        result = await session.execute(
            select(Document).order_by(Document.created_at.desc())
        )
        docs = result.scalars().all()
        return [
            {"id": str(doc.id), "filename": doc.filename, "status": doc.status}
            for doc in docs
        ]

# ------------------ Health Check ------------------ #
@router.get("/api/v1/health")
async def health_check():
    return {"status": "ok", "service": "KMRL IDMS Phase 1"}
