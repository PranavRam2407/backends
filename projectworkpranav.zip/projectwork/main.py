import logging
import uvicorn
from fastapi import FastAPI
from routes import router          #  absolute import
from services import db_service    #  absolute import

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("kmrl_idms")

app = FastAPI(title="KMRL IDMS Phase 1", version="1.0.1")
app.include_router(router)

@app.on_event("startup")
async def startup():
    await db_service.create_tables()
    logger.info("KMRL IDMS Phase 1 started")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
