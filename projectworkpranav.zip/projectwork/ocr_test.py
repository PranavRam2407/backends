import pytesseract
from PIL import Image
import fitz
import io
from preprocessor import TextPreprocessor

# Set Tesseract path
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Initialize preprocessor
text_preprocessor = TextPreprocessor(lowercase=False)

def ocr_pdf_pages(pdf_path: str, start_page: int = 1, end_page: int = None, dpi: int = 300, lang: str = "mal+eng") -> dict:
    doc = fitz.open(pdf_path)
    total_pages = doc.page_count
    end_page = end_page or total_pages
    start_page = max(1, start_page)
    end_page = min(end_page, total_pages)

    extracted_text = {}

    for page_num in range(start_page, end_page + 1):
        try:
            page = doc[page_num - 1]  # 0-indexed
            pix = page.get_pixmap(dpi=dpi)
            img = Image.open(io.BytesIO(pix.tobytes()))

            # OCR
            raw_text = pytesseract.image_to_string(img, lang=lang)
            # Preprocess text
            clean_text = text_preprocessor.preprocess(raw_text)

            extracted_text[page_num] = clean_text or "[BLANK PAGE]"

        except Exception as e:
            extracted_text[page_num] = f"[ERROR extracting page: {e}]"

    doc.close()
    return extracted_text

if __name__ == "__main__":
    pdf_path = input("PDF path: ").strip()
    start_page = int(input("Start page: ").strip() or 1)
    end_page_input = input("End page (blank for last page): ").strip()
    end_page = int(end_page_input) if end_page_input else None

    pages_text = ocr_pdf_pages(pdf_path, start_page, end_page)

    for page, text in pages_text.items():
        print(f"\n--- OCR + Preprocessed Page {page} ---\n{text}\n{'-'*50}")
