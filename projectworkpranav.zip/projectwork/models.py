import uuid
from datetime import datetime
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import Column, String, Integer, DateTime, Text, Float, JSON, ForeignKey
from sqlalchemy.dialects.postgresql import UUID  # Use native UUID in Postgres

# ------------------ Base ------------------ #
Base = declarative_base()

# ------------------ Document Table ------------------ #
class Document(Base):
    __tablename__ = "documents"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    filename = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    file_size = Column(Integer)
    checksum = Column(String)
    pages = Column(Integer)
    status = Column(String, default="uploaded")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    doc_metadata = Column(JSON)

    # Relationships
    extracted_texts = relationship("ExtractedText", back_populates="document", cascade="all, delete-orphan")
    department_contents = relationship("DepartmentContent", back_populates="document", cascade="all, delete-orphan")

# ------------------ Extracted Text Table ------------------ #
class ExtractedText(Base):
    __tablename__ = "extracted_texts"  # make plural for consistency

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    page_number = Column(Integer, nullable=False)
    text_content = Column(Text)
    language = Column(String)
    confidence = Column(Float)
    ocr_engine = Column(String, default="tesseract")
    bbox = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship
    document = relationship("Document", back_populates="extracted_texts")

# ------------------ Department Content Table ------------------ #
class DepartmentContent(Base):
    __tablename__ = "department_contents"  # make plural for consistency

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    department = Column(String, nullable=False)
    content = Column(Text)
    page_start = Column(Integer)
    page_end = Column(Integer)
    confidence = Column(Float)
    keywords_matched = Column(JSON)
    pdf_path = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationship
    document = relationship("Document", back_populates="department_contents")

# ------------------ Add more tables here if needed ------------------ #
# e.g., Users, Departments, Settings, etc.
